## spacesXYZ

<!---
For interactive calculations using this package see:
[**RGB and CIE and Munsell Color Calculator**](http://gluonics.com:85/converter.html)
-->


Possible future work:

- Add some non-linear Chromatic Adaptation Transform (CAT) methods.
- The CIE 1976 color difference metric certainly satisfies the triangle inequality, but what about the other metrics ?  Write a vignette that investigates this question.
